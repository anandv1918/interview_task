            
<h2>Welcome to Admin Portal</h2>
<p>Use the navigation on the left to manage customers and invoices.</p>